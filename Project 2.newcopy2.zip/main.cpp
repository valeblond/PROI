#include <iostream>
#include <cstring>
#include <cstdlib>
#include "Collection.h"

using namespace std;
void menu()
{
    Collection <string, string, string> myCol;
    int way = 1;
    while(way != 0)
        {
            cout << "1.Add a Picture \n2.Delete a Picture \n3.Edit a Picture \n4.Search a Picture \n5.Print a Collection \n0.Exit" << endl;
            cin >> way;
            switch(way)
            {
                case 1:
                    {
                        //string name, author, date;
                        //cout<<"Enter the name of the picture"<<endl;
                        //cin<< name;

                        myCol.AddPicture("Valera","Lol","03/09/1298");
                        myCol.AddPicture("Adam","Dance","02/12/2000");
                        myCol.AddPicture("Witold","Luna","09/09/1997");
                        myCol.AddPicture("Piotr","comedy","12/10/1990");
                        myCol.AddPicture("Michal","Bridge","05/09/1978");
                        break;
                    }
                case 2:
                    {
                        int id;
                        cout << "Enter the id of the picture that you want to delete:";
                        cin >> id;
                        myCol.DelPicture(id);
                        break;
                    }
                case 3:
                    {
                        int id;
                        cout << "Enter the picture's id: ";
                        cin >> id;
                        myCol.EditPicture(id);
                        break;
                    }
                case 4:
                    {
                        cout << "1.By name of the picture \n2.By Id" <<endl;
                        cin >> way;
                        switch(way)
                        {
                            case 1:
                                {
                                    string searchName;
                                    cout<<"Enter the name: ";
                                    cin >> searchName;
                                    cout << myCol.SearchmyCol(searchName);
                                    break;
                                }
                            case 2:
                                {
                                    int number;
                                    cout<<"Enter the number: ";
                                    cin >> number;
                                    cout << myCol.SearchmyCol(number);
                                    break;
                                }
                            default:
                                {
                                    cout << "Wrong way, try one more time!" << endl;
                                    break;
                                }
                        }
                        break;
                    }
                case 5:
                    {
                        cout << myCol.ShowmyCol();
                        break;
                    }
                case 0:
                    cout << "Goodbye!" << endl;
                    break;
                default:
                    cout << "Wrong way, try one more time!" << endl;
                    break;
            }
        }
}

int main ()
{
    menu();
    return 0;
}
