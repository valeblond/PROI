#include <cstring>
#include <cstdlib>

using namespace std;

template <typename C1, typename C2, typename C3>
class Picture
{
private:
    int id;
    C1 author;
    C2 name;
    C3 date;
public:
    Picture<C1,C2,C3> *left;
    Picture<C1,C2,C3> *right;
    void setId(int id)
    {
        this->id = id;
    }
    void setauthor(C1 newauthor)
    {
        this->author = newauthor;
    }
    void setDate(C3 newDate)
    {
        this->date = newDate;
    }
    void setName(C2 newName)
    {
        this->name = newName;
    }
    void setLeft(Picture<C1,C2,C3>* newLeft)
    {
        this->left = newLeft;
    }
    void setRight(Picture<C1,C2,C3>* newRight)
    {
        this->right = newRight;
    }
    C2 getName()
    {
        return this->name;
    }
    C3 getDate()
    {
        return this->date;
    }
    C1 getauthor()
    {
        return this->author;
    }
    int getId()
    {
        return this->id;
    }
    /*void addInfo()
    {
        C2 newName;
        C3 newDate;
        C1 newauthor;
        cout << "Please enter the picture name: ";
        cin >> newName;
        cout << endl << "Please enter a date: ";
        cin >> newDate;
        cout << endl << "Let's add the author: ";
        cin >> newauthor;

        Picture<C1,C2,C3>::setauthor(newauthor);
        Picture<C1,C2,C3>::setName(newName);
        Picture<C1,C2,C3>::setDate(newDate);

        cout << endl << "The new picture was added successfully!" << endl;
    }*/

    Picture(int id = 0, C1 author = "none", C2 name = "none", C3 date = 00/00/0000, Picture<C1,C2,C3>* l = NULL, Picture<C1,C2,C3>* r = NULL)
    {
        setId(id);
        setauthor(author);
        setName(name);
        setDate(date);
        setLeft(l);
        setRight(r);
    }

};

