#include <cstring>
#include <cstdlib>
#include "Picture.h"

using namespace std;

template <typename T1, typename T2, typename T3>
class Collection
{
private:
    int q;
    string result = "";
protected:
    Picture <T1, T2, T3> *root;
public:
    Collection()
    {
        q = 0;
        root = NULL;
    }

    void EditPicture(int id)
    {
        if(id >= q || id < 0){cout<<"There is no picture with this id!"<<endl;}
        else
        {
            cout << "What do you want to change? \n1.Name \n2.Author \n3.Date of edition" << endl;
            int way;
            cin >> way;
            Picture <T1, T2, T3> * t = SearchPart(root,id);
            switch(way)
            {
                case 1:
                {
                    T2 newName;
                    cout << "Enter a new name: ";
                    cin >> newName;
                    t->setName(newName);
                    break;
                }
                case 2:
                {
                    T1 newauthor;
                    cout << "Enter a new author: ";
                    cin >> newauthor;
                    t->setauthor(newauthor);
                    break;
                }
                case 3:
                {
                    T3 newDate;
                    cout << "Enter a new date: ";
                    cin >> newDate;
                    t->setDate(newDate);
                    break;
                }
            }
        }
    }

    void add(Picture <T1, T2, T3> *&t, int id, T1 author, T2 name, T3 date)
    {
        if(t == NULL)
        {
            t = new Picture <T1, T2, T3>(id, author, name, date);
        }
        else
            {
                if(id < t->getId())
                {
                add(t->left, id, author, name, date);
                }
                else
                    {
                        add(t->right, id, author, name, date);
                    }
            }
    }

    void AddPicture(T1 author, T2 name, T3 date)
    {
        add(root, q, author, name, date);
        q++;
    }

    void DelPicture(int id)
    {
        if(id>=q || id<0 || q<=0){cout << "There is no pictures with id = " << id << endl;}
            else
            {
                int i = q - 1;
                Picture <T1, T2, T3> * t = SearchPart(root, id);
                Picture <T1, T2, T3> * l = SearchPart(root, i);
                t->setauthor(l->getauthor());
                t->setName(l->getName());
                t->setDate(l->getDate());
                if(q != 1)
                {
                    Picture <T1, T2, T3> * parent = SearchPart(root, --i);
                    parent->right = NULL;
                    parent->left = NULL;
                    delete(l);
                }else{root = NULL; delete(l);}
                q--;
            }
    }

    string showPart(Picture <T1, T2, T3> *&t )
    {
        if (t != NULL)
            {
                showPart( t->left );
                string str;
                int digit = (t->getId());
                str = digit + '0';
                result = result + "#" + str + "\t Author:" + t->getauthor() + "\t Name:" + t->getName() + "\t Date:" + t->getDate() + "\n";
                str = "";
                showPart( t->right );
            }
        else{if(q==0){result = "Collection is empty.\n";}}
        return result;
    }

    string ShowmyCol()
    {
        string res = showPart(root);
        result = "";
        return res;
    }

    Picture <T1, T2, T3>* SearchPart(Picture <T1, T2, T3> *&t, int id)
    {
        if (q==0)
        {
            cout << "My collection is empty!" << endl;  // not found
        }
        if(t->getId() == id)
        {
            return t;// Got it!!!
        }
        if (id<t->getId())
        {
          if (t->left)
            return SearchPart(t->left, id);
        }
        else
          {
          //right
            return SearchPart(t->right,id);
          }
    }

    string SearchmyCol(int id)
    {
        Picture <T1, T2, T3> *t = SearchPart(root, id);
        string str;
        int digit = (t->getId());
        str = digit + '0';
        result = result + "#" + str + "\t Author:" + t->getauthor() + "\t Name:" + t->getName() + "\t Date:" + t->getDate() + "\n";
        return result;
    }

    string SearchPart(Picture <T1, T2, T3> *&t,T2 filter)
    {
        if (q==0)
        {
            return  "My collection is empty!" ; // not found
        }
        else
        {
           if (t != NULL)
            {
               SearchPart( t->left, filter );
                    if (t->getName() == filter)
                    {
                        string str;
                        int digit = (t->getId());
                        str = digit + '0';
                         result = result + "#" + str + "\t Author:" + t->getauthor() + "\t Name:" + t->getName() + "\t Date:" + t->getDate() + "\n";
                        str = "";
                    }
                SearchPart( t->right, filter );
            }
            if (result == "") return "You gave the wrong author!!! Try one more time.\n";
            else return result;
        }
    }

    string SearchmyCol(T2 searchName)
    {
        string res = SearchPart(root, searchName);
        result = "";
        return res;

    }

};
