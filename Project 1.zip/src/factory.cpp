#include<iostream>
#include<cstring>
#include<stdlib.h>
#include<ctime>
#include "factory.h"
using namespace std;


 factory::factory()
{
    countCar = 0;
    days = 0;
    n = 900000;
    addCar("Mercedez", "black",  66,  800,   500000,  "free");
    addCar("Audi",     "red",    70,  900,   1115000, "free");
    addCar("Ferari",   "gold",   300, 18000, 40000, "free");
    addCar("BMW",      "white",  80,  700,   800000,  "free");
    addCar("Dodge",    "purple", 76,  400,   750000, "free");
    for (int i=0; i<countCar; i++)
    {
        cars[i].initDaysToZero();
    }
}

void factory::addCar(string name, string color, int tank, int parcels, int run, string status)
{

    cars[countCar].addCar(name, color, tank, parcels, run, status);

    countCar++;
}

void factory::removeCar(int numb)
{
    if (numb < 0 && numb>=(countCar))
    {
        cout << "Error! Try again!" << endl;
        return;
    }


        cars[numb] = cars[countCar-1];
        countCar--;
                    /*
                    cars[numb].name = cars[countCar-1].name;
                    cars[numb].color = cars[countCar-1].color;
                    cars[numb].tank = cars[countCar-1].tank;
                    cars[numb].parcels = cars[countCar-1].parcels;
                    cars[numb].run = cars[countCar-1].run;
                    cars[numb].status = cars[countCar-1].status;
                    */

}

        void factory::showCar ()
        {
            cout << "\nYour factory has " << countCar << " cars at the moment " << endl;
            sendToSerwis();
            for (int i = 0; i < countCar; i++ )
            {
                cars[i].showcar(n);
                /*
                if(cars[i].status == "serwis")
                {
                    cars[i].s_days -= 1;
                    if(cars[i].s_days == 0)
                        {
                            cars[i].run -= n;
                            cars[i].status = "free";
                        }

                }
                */
            }
            sendToWork();
            for (int i = 0; i < countCar; i++ )
            {
                cars[i].showMoreCar(i);
                /*
                cout << "Id of the car #" << i << "\tName: " << cars[i].name << "\tColor: " <<  cars[i].color  ;
                cout << "\tTank: " << cars[i].tank << "\t\n\t\t\tParcels: " << cars[i].parcels << "\tRun: " << cars[i].run << "\tStatus: " << cars[i].status << endl << endl;
                */
            }
        }

        void factory::sendToWork()
        {
            for (int i = 0; i < countCar; i++ )
            {
                cars[i].sendToWork();
                /*
                if (cars[i].status == "work" )
                {
                    cars[i].s_days--;
                    if(cars[i].s_days==0)
                    {
                        cars[i].status= "free";
                    }
                }
                */
            }
        }

        void factory::sendToSerwis()
        {
            for (int i = 0; i < countCar; i++ )
            {
                cars[i].sendToSerwis(n);
               /*
                if (cars[i].run >= n )
                {
                    cars[i].status = "serwis";
                    if(cars[i].s_days == 0)
                    {
                            srand(time(0));
                            cars[i].s_days = rand()%4 + 2;
                            cout << cars[i].s_days -1 << endl;
                    }

                }
                */
            }

        }

void factory::goToMission(int parcels)
{

    int bestCar = -1;

    for (int i=0; i < countCar;i++ )
    {
        //cars[i].goToMission(parcels,i,d);

        if(cars[i].getStatus() == "free" && cars[i].getParcels() >= parcels)
        {
            if(bestCar == -1)
            {
                bestCar = i;
            }
            else
            {
                if(cars[bestCar].getParcels() > cars[i].getParcels())
                {
                    bestCar = i;
                }
            }
        }
    }
    if(bestCar == -1)
    {
        cout << "ERROR! You've pointed the wrong number of the parcels or the car that can do this is busy at the moment! Try again! " << endl;
        return;
    }



    cars[bestCar].setStatus("work");
    srand(time(0));
    cars[bestCar].setDays((rand() % 4) + 1);
    cout<< cars[bestCar].getDays() << endl;



}
                /*
                if (cars[i].status == "free" && cars[i].parcels >= parcels)
                    {
                        if(n != -1)
                            {
                                if(cars[n].parcels > cars[i].parcels)
                                    {
                                         n = i;
                                    }
                            }
                            else{n = i;}
                    }

            }

            if(d == -1)
                {
                    cout << "ERROR! You've pointed the wrong number of the parcels or the car that can do this is busy at the moment! Try again! " << endl;
                }else   {
                            cars[n].goToMission1();
                            /*
                            cars[n].status = "work";
                            srand(time(0));
                            cars[n].s_days = rand()%4 + 1;
                            cout<< cars[n].s_days << "\t\t\t"<<endl;
                            */
                        //}



        void factory::menu()
        {
            cout << "\t\t\t\n What would you like to do with your cars: " << endl;
            cout << "\t 1. Add car." << endl;
            cout << "\t 2. Remove car." << endl;
            cout << "\t 3. Send to the mission." << endl;
            cout << "\t 4. Quit from the program." << endl << endl;
        }

        void factory::createNewCar()
        {
            cars[countCar].createNewCar();
            /*
            cout << "Write the name of your car: " ;
            cin >> cars[countCar].name;
            cout << "Write the color of your car: " ;
            cin >> cars[countCar].color;
            cout << "Write the tank of your car: " ;
            cin >> cars[countCar].tank;
            cout << "Write how many parcels your car can lift: " ;
            cin >> cars[countCar].parcels;
            cout << "Write the run of your car: ";
            cin >> cars[countCar].run;
            cars[countCar].status = "free";
            */
            countCar++;
            showCar1 ();
        }

        void factory::whatchoose (int punkt)
        {
            cout << "You've chosen punkt " << punkt << endl;
            int numb,parcels;
                switch(punkt)
                {
                    case 1: {
                                createNewCar();
                            }break;
                    case 2:  {
                                cout << "Write the id of the car that you want to remove: ";
                                cin>>numb;
                                removeCar(numb);
                                showCar1 ();
                             }break;
                    case 3: {
                                cout << "Write how many parcels you'd like to send: ";
                                cin >> parcels;
                                goToMission(parcels);
                                showCar ();
                                days++;
                            }break;
                    case 4: break;
                    default : cout << "You've chosen the wrong number! Try again!" << endl;
                }
        }

        void factory::showCar1()
        {
            cout << "\nYour factory has " << countCar << " cars at the moment " << endl;

            for (int i = 0; i < countCar; i++ )
            {
                //cout << cars[i];
                cars[i].showCar1(i);
                /*
                cout << "Id of the car #" << i << "\tName: " << cars[i].name << "\tColor: " <<  cars[i].color  ;
                cout << "\tTank: " << cars[i].tank << "\t\n\t\t\tParcels: " << cars[i].parcels << "\tRun: " << cars[i].run << "\tStatus: " << cars[i].status << endl <<endl;
                */
            }
        }


        void factory::check (int punkt)
        {
            while (punkt != 4)
            {
                menu();
                cin >> punkt;
                whatchoose(punkt);
            } cout << "You've closed your program!\n\t\t\t\t\t -_- Goodbye!!! -_- " << endl;
        }



