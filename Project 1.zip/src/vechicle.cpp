#include<iostream>
#include<cstring>
#include<stdlib.h>
#include<ctime>
#include "vechicle.h"

vechicle::vechicle()
{

}


void vechicle::setParcels(int prc)
{
    (this->parcels) = prc;
}
int vechicle::getParcels()const
{
    return (this->parcels);
}
void vechicle::setStatus(string stat)
{
    (this->status) = stat;
}
string vechicle::getStatus()
{
      return (this->status);
}
void vechicle::setDays(int days)
{
    (this->s_days) = days;
}
int vechicle::getDays()const
{
    return (this->s_days);
}





void vechicle::addCar(string name, string color, int tank, int parcels, int run, string status)
{
    this->name = name;
    this->color = color;
    this->tank = tank;
    this->parcels = parcels;
    this->run = run;
    this->status = status;
}

void vechicle::sendToSerwis(int n)
{
    if ((this->run) >= n )
                {
                    this->status = "serwis";
                    if(this->s_days == 0)
                    {
                            srand(time(0));
                            this->s_days = rand()%4 + 2;
                            cout << this->s_days -1 << endl;
                    }
                }
}

void vechicle::showcar(int n)
{
    if(this->status == "serwis")
                {
                    this->s_days -= 1;
                    if(this->s_days == 0)
                        {
                            this->run -= n;
                            this->status = "free";
                        }
                }
}

void vechicle::sendToWork()
{
        if (this->status == "work" )
                {
                    this->s_days--;
                    if(this->s_days==0)
                    {
                        this->status= "free";
                    }
                }

}

void vechicle::showMoreCar(int i)
{
     cout << "Id of the car #" << i << "\tName: " << this->name << "\tColor: " <<  this->color  ;
     cout << "\tTank: " << this->tank << "\t\n\t\t\tParcels: " << this->parcels << "\tRun: " << this->run << "\tStatus: " << this->status << endl << endl;
}

void vechicle::initDaysToZero()
{
    this->s_days = 0;
}




void vechicle::createNewCar()
{
    cout << "Write the name of your car: " ;
    cin >> this->name;
    cout << "Write the color of your car: " ;
    cin >> this->color;
    cout << "Write the tank of your car: " ;
    cin >> this->tank;
    cout << "Write how many parcels your car can lift: " ;
    cin >> this->parcels;
    cout << "Write the run of your car: ";
    cin >> this->run;
    this->status = "free";
}

void vechicle::showCar1(int i)
{
    cout << "Id of the car #" << i << "\tName: " << this->name << "\tColor: " <<  this->color  ;
    cout << "\tTank: " << this->tank << "\t\n\t\t\tParcels: " << this->parcels << "\tRun: " << this->run << "\tStatus: " << this->status << endl <<endl;
}
