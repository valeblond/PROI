#include <iostream>
#include <cstring>
#include "factory.h"

using namespace std;

int main()
{
        int punkt = 0;
        factory fact;
        fact.showCar();
        fact.check(punkt);



    return 0;
}
