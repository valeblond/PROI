#ifndef VECHICLE_H
#define VECHICLE_H
#include<iostream>
#include<cstring>

using namespace std;

class vechicle
{
    private:
        string name;
        string color;
        int tank;
        int parcels;
        int run;
        string status;
        int s_days;


    public:
        vechicle();
        //void setName();
        //string getName()const;
        void setParcels(int);
        int getParcels()const;
        void setStatus(string);
        string getStatus();
        void setDays(int);
        int getDays()const;
        void addCar(string, string, int, int, int, string);
        void sendToSerwis(int);
        void showcar(int);
        void sendToWork();
        void showMoreCar(int);
        void initDaysToZero();


        void createNewCar();
        void showCar1(int);


        protected:


};

#endif // VECHICLE_H
