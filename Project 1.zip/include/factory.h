#ifndef FACTORY_H
#define FACTORY_H
#include<iostream>
#include<cstring>
#include"vechicle.h"
// class car,
// przeciazenia operatorow
// class menu

class factory
{
    protected:
        int countCar;
        int days;
        int n;//when a car will need service

        vechicle cars[1000];
    public:
        factory();

        friend vechicle;

        void addCar(std::string, std::string, int, int, int, std::string);

        void removeCar(int);

        void showCar();

        void sendToWork();

        void sendToSerwis();

        void goToMission(int);

        void menu();

        void createNewCar();

        void whatchoose (int);

        void showCar1 ();

        void check (int );



    private:

};

#endif // FACTORY_H
